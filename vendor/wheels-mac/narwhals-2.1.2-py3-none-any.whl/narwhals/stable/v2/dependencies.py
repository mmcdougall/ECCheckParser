from __future__ import annotations

from narwhals.dependencies import *  # noqa: F403
